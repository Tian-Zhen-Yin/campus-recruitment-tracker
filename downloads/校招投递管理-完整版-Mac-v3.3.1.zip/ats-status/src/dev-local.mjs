// 本机开发专用回退（被 .gitignore 排除，不进公开仓库与安装包）
export const DEV_TRACKER = '/Users/yintao/Library/Application Support/TRAE SOLO CN/ModularData/ai-agent/work-mode-projects/6a9baf97158d987db4c04384/autumn-recruitment-tracker';
