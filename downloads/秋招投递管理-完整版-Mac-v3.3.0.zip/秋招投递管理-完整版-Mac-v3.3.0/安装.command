#!/bin/bash
cd "$(dirname "$0")"
bash ats-status/scripts/install.sh
read -n 1 -s -r -p "安装结束，按任意键关闭本窗口…"
