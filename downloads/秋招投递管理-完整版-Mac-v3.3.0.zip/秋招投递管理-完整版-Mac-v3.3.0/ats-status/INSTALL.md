# 安装说明（给同学的一页纸）

> 纯网页版（只记投递、不装后台）的地址：https://tian-zhen-yin.github.io/autumn-recruitment-tracker/

这是一份「秋招投递管理」完整版：一个记投递的**台账**网页 + 一个在你电脑后台帮你盯官网进展的**控制台**。全程本地运行，你的投递记录、官网登录、邮箱授权码都只存在你自己电脑里。

## 你需要

- 一台 Mac（Intel 或 Apple 芯片都行）
- Chrome 浏览器（官网登录窗口用它）
- Node.js ≥ 18（没有就先 `brew install node`，或从 https://nodejs.org 下载安装）

## 安装：一条命令

把这个文件夹放到一个**你不会随便挪动/删除**的位置（服务登记的是当前路径），然后在终端进入文件夹执行：

```bash
bash scripts/install.sh
```

脚本会自动：检查环境 → 安装依赖 → 注册常驻服务和定时任务（工作日 9:30 / 14:30 / 20:00 自动查官网进展并检查邮箱）→ 打开台账页面。中途弹出的任何窗口都来自安装步骤本身。

只想先看看会改什么？`bash scripts/install.sh --dry-run`

## 装完之后

1. 台账会自动打开（`http://127.0.0.1:7788/`），建议收藏到书签；
2. 在「找岗位」或手动「新增投递」记录你的投递；
3. 到「自动跟进」接入你投过的公司（点「去接入」扫码，登一次即可）；
4. 想要面试邀约自动提醒：控制台「邮件与推送」里配置你的邮箱授权码；
5. 忘了怎么用就打开「使用指南」（台账「设置」里有入口）。

## 常见问题

- **端口被占用**（提示 7788 被占）：换端口启动 `PORT=7890 node src/cli.mjs ui`，台账会照常跟随新端口。
- **想看后台在干什么**：控制台页有运行日志；日志文件在 `~/.ats-status/out/`。
- **某家公司登录过期**：台账「自动跟进」里该司显示「待完成登录」，点「去接入」重新扫码。
- **不想用了 / 彻底卸载**：终端执行
  ```bash
  launchctl bootout gui/$(id -u)/com.ats-status.console
  launchctl bootout gui/$(id -u)/com.ats-status.schedule
  rm ~/Library/LaunchAgents/com.ats-status.console.plist ~/Library/LaunchAgents/com.ats-status.schedule.plist
  rm -rf ~/.ats-status   # 登录会话等个人数据都在这里，删掉即无残留
  ```
  然后删除本文件夹。台账浏览器数据在该站点「清除网站数据」即可。

## 只想要「记投递」，不想装后台？

用纯网页版就够了（本仓库的 GitHub Pages 地址，或离线包）：记录、岗位库、截图识别、拍板全部可用，只是没有「自动跟进官网」和「邮件邀约」。数据同样只在你自己的浏览器里。
