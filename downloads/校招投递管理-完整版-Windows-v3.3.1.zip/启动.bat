@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ats-status\scripts\win\start.ps1" %*
